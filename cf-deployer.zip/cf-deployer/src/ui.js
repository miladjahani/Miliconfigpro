// پوستهٔ SPA استقراردهنده: تمام‌SVG، RTL، تم فیروزه‌ای + سبز نئونی.
// هیچ ایموجی و هیچ تصویر PNG استفاده نمی‌شود.

const I = {
  logo: `<svg class="logo" viewBox="0 0 64 64" fill="none" aria-hidden="true">
    <circle cx="32" cy="32" r="30" fill="#08110b" stroke="#65a30d" stroke-width="1.5" stroke-opacity=".7"/>
    <path d="M32 15l13 5.6v10.2C45 40.2 39.4 48.2 32 51 24.6 48.2 19 40.2 19 30.8V20.6L32 15z" stroke="#b5ff4d" stroke-width="3" stroke-linejoin="round"/>
    <path d="M32 23v11m0 0-5-4.2m5 4.2 5-4.2" stroke="#63e6d4" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`,
  upload: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20.5v-11"/><path d="m7.6 13.4 4.4-4.4 4.4 4.4"/><path d="M4.5 4.5h15"/></svg>`,
  zip: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3H8.5A2.5 2.5 0 0 0 6 5.5v13A2.5 2.5 0 0 0 8.5 21h7a2.5 2.5 0 0 0 2.5-2.5V6z"/><path d="M15 3v3.4h3"/><path d="M12 7.4v1.3M12 10.4v1.3M12 13.4v1.3M12 16.4v1.3"/></svg>`,
  file: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7.5A2.5 2.5 0 0 0 5 5.5v13A2.5 2.5 0 0 0 7.5 21h9a2.5 2.5 0 0 0 2.5-2.5V8z"/><path d="M14 3v5h5"/><path d="M8.5 13h7M8.5 16.5h4.5"/></svg>`,
  link: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M10.2 6.8 12.6 4.4a4.1 4.1 0 0 1 5.8 5.8l-2.4 2.4"/><path d="M13.8 17.2 11.4 19.6a4.1 4.1 0 0 1-5.8-5.8l2.4-2.4"/><path d="m9.4 14.6 5.2-5.2"/></svg>`,
  github: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9.4 20.4v-3.1c-2.6.5-3.3-1.2-3.3-1.2-.4-1-1-1.3-1-1.3-.9-.6.1-.6.1-.6 1 .1 1.5 1 1.5 1 .9 1.5 2.3 1.1 2.9.8.1-.6.3-1.1.6-1.3-2.1-.2-4.2-1-4.2-4.6 0-1 .4-1.9 1-2.5-.1-.3-.4-1.2.1-2.5 0 0 .8-.2 2.6 1a8.9 8.9 0 0 1 4.6 0c1.8-1.2 2.6-1 2.6-1 .5 1.3.2 2.2.1 2.5.6.6 1 1.5 1 2.5 0 3.6-2.1 4.4-4.2 4.6.3.3.6.9.6 1.8v2.7"/></svg>`,
  server: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="4" width="17" height="6.4" rx="2"/><rect x="3.5" y="13.6" width="17" height="6.4" rx="2"/><path d="M7 7.2h.01M7 16.8h.01"/></svg>`,
  layers: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3.5 8.4 4.4L12 12.3 3.6 7.9 12 3.5z"/><path d="m4.6 12.4 7.4 3.9 7.4-3.9"/><path d="m4.6 16.6 7.4 3.9 7.4-3.9"/></svg>`,
  check: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="m4.5 12.5 4.8 4.8L19.5 6.8"/></svg>`,
  close: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="m6 6 12 12"/><path d="m18 6-12 12"/></svg>`,
  refresh: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.4-5.7"/><path d="M20 4v4.4h-4.4"/></svg>`,
  terminal: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4.5" width="18" height="15" rx="2.6"/><path d="m7.4 9.6 2.6 2.4-2.6 2.4"/><path d="M12.8 14.6h3.8"/></svg>`,
  shield: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 20 6.2v5.4c0 4.9-3.3 8.6-8 10.4-4.7-1.8-8-5.5-8-10.4V6.2L12 3z"/><path d="m8.8 12 2.4 2.4 4-4.4"/></svg>`,
  clock: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.6"/><path d="M12 7.4V12l3.2 2"/></svg>`,
  trash: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 7h15"/><path d="M9.5 7V4.8h5V7"/><path d="M6.5 7l.9 12.2h9.2L17.5 7"/></svg>`,
  copy: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2.4"/><path d="M15.2 6.4V5.6A2.4 2.4 0 0 0 12.8 3.2H6.4A2.4 2.4 0 0 0 4 5.6v6.4a2.4 2.4 0 0 0 2.4 2.4h.8"/></svg>`,
  bolt: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M13.2 2.8 4.8 13.4h5.6l-1.2 7.8 8.8-11h-5.8l1-7.4z"/></svg>`,
  globe: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.8"/><path d="M3.4 12h17.2"/><path d="M12 3.2c2.6 2.4 3.9 5.4 3.9 8.8s-1.3 6.4-3.9 8.8c-2.6-2.4-3.9-5.4-3.9-8.8S9.4 5.6 12 3.2z"/></svg>`,
  key: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="15" r="4"/><path d="m11 12 8-8"/><path d="m16 4 4 4"/><path d="m14 6 4 4"/></svg>`,
  plus: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M12 5v14"/><path d="M5 12h14"/></svg>`,
  external: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M13.5 4.5h6v6"/><path d="m19.5 4.5-8 8"/><path d="M18 14v4.2a1.8 1.8 0 0 1-1.8 1.8H5.8A1.8 1.8 0 0 1 4 18.2V7.8A1.8 1.8 0 0 1 5.8 6H10"/></svg>`,
  warning: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.6 21 19.4H3z"/><path d="M12 9.4v4.4"/><path d="M12 17h.01"/></svg>`,
  telegram: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M20.6 4.2 2.9 11.1c-.9.4-.9 1.5.1 1.8l4.3 1.3 1.6 4.9c.3.8 1.3 1 1.8.3l2.3-2.7 4.5 3.3c.7.5 1.7.1 1.9-.8l2.5-13.8c.2-1-.8-1.7-1.3-1.2z"/><path d="m7.3 14.2 10.9-7.4-8.6 8.2"/></svg>`,
  heart: `<svg class="mi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20.2C7.2 17.4 4 14.3 4 10.7 4 8.1 6 6.2 8.4 6.2c1.5 0 2.8.7 3.6 1.9.8-1.2 2.1-1.9 3.6-1.9C18 6.2 20 8.1 20 10.7c0 3.6-3.2 6.7-8 9.5z"/></svg>`
};

const ICON_JSON = JSON.stringify(I);

// لینک آمادهٔ ساخت توکن کلادفلر با مجوزهای لازم (Workers، Pages، KV، D1، R2 و …)
const TOKEN_URL =
  'https://dash.cloudflare.com/profile/api-tokens?permissionGroupKeys=%5B' +
  '%7B%22key%22%3A%22workers_scripts%22%2C%22type%22%3A%22read%22%7D%2C' +
  '%7B%22key%22%3A%22workers_scripts%22%2C%22type%22%3A%22edit%22%7D%2C' +
  '%7B%22key%22%3A%22workers_kv_storage%22%2C%22type%22%3A%22read%22%7D%2C' +
  '%7B%22key%22%3A%22workers_kv_storage%22%2C%22type%22%3A%22edit%22%7D%2C' +
  '%7B%22key%22%3A%22workers_routes%22%2C%22type%22%3A%22edit%22%7D%2C' +
  '%7B%22key%22%3A%22workers_r2%22%2C%22type%22%3A%22read%22%7D%2C' +
  '%7B%22key%22%3A%22workers_r2%22%2C%22type%22%3A%22edit%22%7D%2C' +
  '%7B%22key%22%3A%22d1%22%2C%22type%22%3A%22read%22%7D%2C' +
  '%7B%22key%22%3A%22d1%22%2C%22type%22%3A%22edit%22%7D%2C' +
  '%7B%22key%22%3A%22page%22%2C%22type%22%3A%22read%22%7D%2C' +
  '%7B%22key%22%3A%22page%22%2C%22type%22%3A%22edit%22%7D%2C' +
  '%7B%22key%22%3A%22zone%22%2C%22type%22%3A%22read%22%7D%2C' +
  '%7B%22key%22%3A%22zone_settings%22%2C%22type%22%3A%22read%22%7D%2C' +
  '%7B%22key%22%3A%22zone_settings%22%2C%22type%22%3A%22edit%22%7D%2C' +
  '%7B%22key%22%3A%22dns%22%2C%22type%22%3A%22read%22%7D%2C' +
  '%7B%22key%22%3A%22dns%22%2C%22type%22%3A%22edit%22%7D%2C' +
  '%7B%22key%22%3A%22ssl_and_certificates%22%2C%22type%22%3A%22edit%22%7D%2C' +
  '%7B%22key%22%3A%22cache%22%2C%22type%22%3A%22purge%22%7D%2C' +
  '%7B%22key%22%3A%22account_settings%22%2C%22type%22%3A%22read%22%7D%2C' +
  '%7B%22key%22%3A%22account_analytics%22%2C%22type%22%3A%22read%22%7D%2C' +
  '%7B%22key%22%3A%22account_api_tokens%22%2C%22type%22%3A%22read%22%7D' +
  '%5D&accountId=*&zoneId=all&name=Miliconfig';

export function renderAppHtml({ origin = '' } = {}) {
  return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cloud Deployer — استقرار پنل روی کلادفلر</title>
<meta name="description" content="استقرار پنل و ورکر روی Cloudflare Workers و Pages بدون خطای 1101">
<link rel="icon" href="data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="32" r="30" fill="#05080a" stroke="#a3e635" stroke-width="3"/><path d="M32 15l13 5.6v10.2C45 40.2 39.4 48.2 32 51 24.6 48.2 19 40.2 19 30.8V20.6L32 15z" fill="none" stroke="#b5ff4d" stroke-width="4" stroke-linejoin="round"/><path d="M32 23v11m0 0-5-4.2m5 4.2 5-4.2" fill="none" stroke="#63e6d4" stroke-width="4" stroke-linecap="round"/></svg>`)}">
<style>
  :root {
    --bg: #05080a;
    --panel: rgba(9, 15, 13, 0.9);
    --panel-2: rgba(12, 20, 16, 0.86);
    --line: rgba(181, 255, 77, 0.14);
    --line-aqua: rgba(99, 230, 212, 0.26);
    --aqua: #63e6d4;
    --neon: #b5ff4d;
    --danger: #ff6262;
    --warn: #ffce5c;
    --text: #e9f3e2;
    --muted: #85957f;
    --radius: 18px;
    --shadow: 0 24px 60px rgba(0, 0, 0, 0.55);
    --mono: ui-monospace, SFMono-Regular, Menlo, monospace;
    --font: "Vazirmatn", "Segoe UI", Tahoma, system-ui, sans-serif;
  }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body {
    font-family: var(--font);
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    padding-bottom: 40px;
    -webkit-font-smoothing: antialiased;
  }
  body::before {
    content: "";
    position: fixed; inset: 0; z-index: -2;
    background:
      radial-gradient(900px 480px at 82% -8%, rgba(181, 255, 77, 0.12), transparent 65%),
      radial-gradient(760px 440px at 8% 2%, rgba(99, 230, 212, 0.12), transparent 62%),
      linear-gradient(180deg, #060a0b 0%, #040607 100%);
  }
  body::after {
    content: "";
    position: fixed; inset: 0; z-index: -1;
    background-image:
      linear-gradient(rgba(181, 255, 77, 0.035) 1px, transparent 1px),
      linear-gradient(90deg, rgba(181, 255, 77, 0.035) 1px, transparent 1px);
    background-size: 46px 46px;
    mask-image: radial-gradient(circle at 50% 0%, #000 0%, transparent 78%);
    pointer-events: none;
  }
  a { color: var(--aqua); text-decoration: none; }
  .mi { width: 19px; height: 19px; display: inline-block; vertical-align: middle; flex: none; }
  .wrap { max-width: 1120px; margin: 0 auto; padding: 0 18px; }

  header.top {
    position: sticky; top: 0; z-index: 20;
    background: rgba(5, 9, 8, 0.86);
    backdrop-filter: blur(14px);
    border-bottom: 1px solid var(--line);
  }
  .top-inner { display: flex; align-items: center; gap: 12px; padding: 12px 0; }
  .logo { width: 40px; height: 40px; flex: none; animation: float 6s ease-in-out infinite; }
  .brand-name { font-weight: 800; font-size: 1rem; letter-spacing: .3px; }
  .brand-name span { color: var(--aqua); }
  .brand-sub { font-size: .68rem; color: var(--muted); }
  .spacer { flex: 1; }
  .chip {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 7px 11px; border-radius: 999px; font-size: .72rem;
    border: 1px solid var(--line-aqua); color: var(--aqua);
    background: rgba(99, 230, 212, 0.08);
  }
  .chip.neon { border-color: var(--line); color: var(--neon); background: rgba(181, 255, 77, 0.08); }
  .icon-btn {
    width: 38px; height: 38px; border-radius: 11px; cursor: pointer;
    display: inline-flex; align-items: center; justify-content: center;
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid var(--line); color: var(--text);
    transition: transform .18s ease, background .18s ease, border-color .18s ease, box-shadow .18s ease;
  }
  .icon-btn:hover { transform: translateY(-1px); border-color: var(--line-aqua); box-shadow: 0 10px 24px rgba(99, 230, 212, 0.16); }
  .icon-btn:active { transform: scale(.95); }

  main { padding-top: 20px; display: grid; gap: 16px; }
  .card {
    border-radius: var(--radius);
    border: 1px solid var(--line);
    background: linear-gradient(180deg, rgba(11, 18, 15, 0.96), rgba(7, 12, 10, 0.96));
    box-shadow: var(--shadow);
    overflow: hidden;
  }
  .card-head {
    display: flex; align-items: center; gap: 9px;
    padding: 13px 16px;
    border-bottom: 1px solid var(--line);
    background: linear-gradient(90deg, rgba(99, 230, 212, 0.07), rgba(181, 255, 77, 0.05));
  }
  .card-head b { font-size: .88rem; }
  .card-head .mi { color: var(--aqua); }
  .card-body { padding: 16px; display: grid; gap: 13px; }
  .hint { font-size: .74rem; color: var(--muted); line-height: 1.9; margin: 0; }
  .hint b { color: var(--text); }

  .field { display: grid; gap: 6px; }
  .field label { font-size: .76rem; color: var(--muted); }
  .field input, .field select, .field textarea {
    width: 100%; padding: 10px 12px; border-radius: 11px;
    background: rgba(3, 7, 6, 0.7); color: var(--text);
    border: 1px solid var(--line); font: inherit; font-size: .82rem;
    transition: border-color .18s ease, box-shadow .18s ease;
  }
  .field input:focus, .field select:focus, .field textarea:focus {
    outline: none; border-color: var(--line-aqua); box-shadow: 0 0 0 3px rgba(99, 230, 212, 0.12);
  }
  .row { display: grid; gap: 12px; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); }

  .btn {
    position: relative; overflow: hidden; cursor: pointer;
    display: inline-flex; align-items: center; justify-content: center; gap: 7px;
    padding: 10px 16px; border-radius: 12px; font: inherit; font-size: .8rem;
    border: 1px solid var(--line); background: rgba(255, 255, 255, 0.03); color: var(--text);
    transition: transform .18s ease, box-shadow .18s ease, background .18s ease;
  }
  .btn:hover { transform: translateY(-1px); }
  .btn:active { transform: scale(.98); }
  .btn.primary {
    border-color: transparent; color: #04120d; font-weight: 700;
    background: linear-gradient(120deg, var(--aqua), var(--neon));
    box-shadow: 0 14px 34px rgba(99, 230, 212, 0.28);
  }
  .btn.ghost { color: var(--muted); }
  .btn.danger { color: var(--danger); border-color: rgba(255, 98, 98, 0.3); }
  .btn.neon { text-decoration: none; color: var(--neon); border-color: rgba(181, 255, 77, 0.42); background: rgba(181, 255, 77, 0.08); }
  .btn.neon:hover { color: #04120d; border-color: transparent; background: linear-gradient(120deg, var(--neon), var(--aqua)); }
  .btn:disabled { opacity: .55; cursor: not-allowed; transform: none; }
  .btn .mi { width: 16px; height: 16px; }

  .tabs { display: flex; gap: 7px; flex-wrap: wrap; }
  .tab {
    cursor: pointer; border: 1px solid var(--line); background: rgba(99, 230, 212, 0.05);
    color: var(--muted); border-radius: 999px; padding: 8px 14px; font: inherit; font-size: .77rem;
    display: inline-flex; align-items: center; gap: 6px;
    transition: all .18s ease;
  }
  .tab:hover { color: #eafffb; background: rgba(99, 230, 212, 0.12); transform: translateY(-1px); }
  .tab.is-active {
    color: #04120d; font-weight: 700; border-color: transparent;
    background: linear-gradient(120deg, var(--aqua), var(--neon));
    box-shadow: 0 10px 26px rgba(99, 230, 212, 0.3);
  }
  .pane { display: none; }
  .pane.is-active { display: grid; gap: 12px; animation: pane .34s ease both; }

  .drop {
    border: 1.5px dashed rgba(99, 230, 212, 0.35);
    border-radius: 16px; padding: 28px 16px; text-align: center;
    background: rgba(99, 230, 212, 0.04); cursor: pointer;
    transition: all .2s ease;
  }
  .drop:hover, .drop.is-over {
    border-color: var(--aqua); background: rgba(99, 230, 212, 0.1);
    box-shadow: inset 0 0 40px rgba(99, 230, 212, 0.08);
  }
  .drop .mi { width: 30px; height: 30px; color: var(--aqua); }
  .drop b { display: block; margin-top: 8px; font-size: .85rem; }
  .drop small { color: var(--muted); font-size: .72rem; }

  .preview-grid { display: grid; gap: 10px; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); }
  .kv {
    border: 1px solid var(--line); border-radius: 12px; padding: 9px 11px;
    background: rgba(99, 230, 212, 0.04);
  }
  .kv span { display: block; font-size: .68rem; color: var(--muted); }
  .kv b { font-size: .84rem; word-break: break-all; }
  .warn-list { margin: 0; padding-inline-start: 18px; color: var(--warn); font-size: .76rem; line-height: 1.9; }
  .ok-line { color: var(--neon); font-size: .78rem; display: flex; align-items: center; gap: 6px; }

  .console {
    font-family: var(--mono); font-size: .75rem; direction: ltr; text-align: left;
    background: #040807; border: 1px solid var(--line); border-radius: 14px;
    padding: 12px; max-height: 340px; overflow-y: auto; display: grid; gap: 5px;
    min-height: 90px;
  }
  .log { display: flex; gap: 8px; align-items: flex-start; animation: lineIn .3s ease both; }
  .log i { flex: none; width: 7px; height: 7px; border-radius: 50%; margin-top: 6px; background: var(--muted); }
  .log.step i { background: var(--aqua); box-shadow: 0 0 10px var(--aqua); }
  .log.ok i { background: var(--neon); box-shadow: 0 0 10px var(--neon); }
  .log.warn i { background: var(--warn); }
  .log.err i { background: var(--danger); }
  .log span { direction: rtl; text-align: right; color: #cfe6da; line-height: 1.8; }
  .console .idle { color: var(--muted); direction: rtl; text-align: right; }

  .result {
    border-radius: 16px; padding: 14px;
    border: 1px solid rgba(181, 255, 77, 0.32);
    background: linear-gradient(120deg, rgba(99, 230, 212, 0.1), rgba(181, 255, 77, 0.08));
    display: grid; gap: 10px;
  }
  .result.bad { border-color: rgba(255, 98, 98, 0.34); background: rgba(255, 98, 98, 0.07); }
  .url-box {
    font-family: var(--mono); font-size: .76rem; direction: ltr;
    background: rgba(0, 0, 0, 0.4); border: 1px solid var(--line);
    border-radius: 10px; padding: 8px 10px; word-break: break-all;
  }

  table.hist { width: 100%; border-collapse: collapse; font-size: .76rem; }
  table.hist th, table.hist td { padding: 9px 8px; text-align: right; border-bottom: 1px solid var(--line); }
  table.hist th { color: var(--muted); font-weight: 500; font-size: .7rem; }
  table.hist td.mono { font-family: var(--mono); direction: ltr; text-align: left; font-size: .72rem; }
  .empty { color: var(--muted); font-size: .78rem; text-align: center; padding: 18px 0; }

  .modal { position: fixed; inset: 0; z-index: 90; display: none; align-items: center; justify-content: center; padding: 16px; background: rgba(2, 5, 4, 0.74); backdrop-filter: blur(6px); }
  .modal.is-open { display: flex; animation: fade .3s ease both; }
  .modal-card {
    width: min(560px, 100%); border-radius: var(--radius);
    border: 1px solid var(--line-aqua); background: #070d0b; box-shadow: var(--shadow);
    overflow: hidden; animation: rise .5s cubic-bezier(.2,.85,.25,1) both;
    max-height: 92vh; display: flex; flex-direction: column;
  }
  .modal-head { display: flex; align-items: center; justify-content: space-between; padding: 13px 15px; border-bottom: 1px solid var(--line); }
  .modal-head b { display: flex; align-items: center; gap: 8px; font-size: .87rem; }
  .modal-foot { padding: 12px 15px; border-top: 1px solid var(--line); display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }

  .help-card { width: min(880px, 100%); border-color: rgba(99, 230, 212, 0.36); background: radial-gradient(800px 360px at 10% -10%, rgba(99,230,212,.15), transparent 62%), #070d0b; }
  .help-tabs { display: flex; gap: 6px; padding: 11px 15px 0; overflow-x: auto; }
  .help-tab { flex: none; cursor: pointer; border: 1px solid var(--line-aqua); background: rgba(99, 230, 212, 0.06); color: var(--muted); border-radius: 999px; padding: 6px 12px; font: inherit; font-size: .73rem; transition: all .18s ease; }
  .help-tab:hover { color: #eafffb; transform: translateY(-1px); }
  .help-tab.is-active { color: #04120d; font-weight: 700; border-color: transparent; background: linear-gradient(120deg, var(--aqua), var(--neon)); }
  .help-body { padding: 13px 16px 8px; overflow-y: auto; }
  .help-pane { display: none; }
  .help-pane.is-active { display: block; animation: pane .32s ease both; }
  .help-pane h4 { margin: 0 0 7px; font-size: .84rem; color: #cffcf6; display: flex; align-items: center; gap: 7px; }
  .help-pane p { margin: 0 0 10px; color: var(--muted); font-size: .78rem; line-height: 1.95; }
  .help-pane ul { margin: 0 0 12px; padding-inline-start: 17px; color: var(--muted); font-size: .77rem; line-height: 1.95; }
  .help-pane li::marker { color: var(--aqua); }
  .kbd { font-family: var(--mono); font-size: .72rem; direction: ltr; display: inline-block; padding: 1px 6px; border-radius: 6px; color: var(--neon); background: rgba(181, 255, 77, 0.1); border: 1px solid rgba(181, 255, 77, 0.25); }
  .foot { display: flex; align-items: center; gap: 9px; flex-wrap: wrap; margin-top: 8px; padding: 16px 0 24px; border-top: 1px solid var(--line); color: var(--muted); font-size: .76rem; }
  .foot-link { display: inline-flex; align-items: center; gap: 7px; padding: 7px 13px; border-radius: 999px; border: 1px solid var(--line-aqua); background: rgba(99, 230, 212, 0.05); color: #d8fffa; text-decoration: none; transition: all .18s ease; }
  .foot-link:hover { border-color: var(--aqua); color: #04120d; background: linear-gradient(120deg, var(--aqua), var(--neon)); transform: translateY(-1px); }
  .foot-link svg { width: 15px; height: 15px; }
  .foot-link.sponsor { border-color: rgba(181, 255, 77, 0.34); background: rgba(181, 255, 77, 0.07); color: var(--neon); }
  .foot-note { margin-inline-start: auto; font-size: .72rem; }
  .help-check { display: flex; align-items: center; gap: 7px; color: var(--muted); font-size: .73rem; margin-inline-start: auto; cursor: pointer; }
  .help-check input { accent-color: var(--aqua); }

  .toast {
    position: fixed; bottom: 18px; left: 50%; transform: translate(-50%, 20px);
    background: #081210; border: 1px solid var(--line-aqua); color: var(--text);
    padding: 10px 16px; border-radius: 12px; font-size: .8rem; z-index: 120;
    opacity: 0; pointer-events: none; transition: all .25s ease;
    box-shadow: var(--shadow); max-width: 90vw;
  }
  .toast.show { opacity: 1; transform: translate(-50%, 0); }
  .toast.err { border-color: rgba(255, 98, 98, 0.5); color: #ffd9d9; }

  .ripple { position: absolute; width: 120px; height: 120px; margin: -60px 0 0 -60px; border-radius: 50%; pointer-events: none; background: radial-gradient(circle, rgba(99, 230, 212, 0.5), transparent 70%); animation: rip .6s ease-out forwards; }

  @keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-3px); } }
  @keyframes fade { from { opacity: 0; } to { opacity: 1; } }
  @keyframes rise { from { opacity: 0; transform: translateY(26px) scale(.96); } to { opacity: 1; transform: none; } }
  @keyframes pane { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
  @keyframes lineIn { from { opacity: 0; transform: translateX(-6px); } to { opacity: 1; transform: none; } }
  @keyframes rip { from { opacity: .8; transform: scale(.2); } to { opacity: 0; transform: scale(1.6); } }

  @media (max-width: 640px) {
    .brand-sub, .chip.hide-sm { display: none; }
    .card-body { padding: 13px; }
    table.hist th:nth-child(3), table.hist td:nth-child(3) { display: none; }
  }
  @media (prefers-reduced-motion: reduce) {
    * { animation-duration: .001s !important; transition-duration: .001s !important; }
  }
</style>
</head>
<body>
  <header class="top">
    <div class="wrap top-inner">
      ${I.logo}
      <div>
        <div class="brand-name">Cloud<span>Deployer</span></div>
        <div class="brand-sub">استقرار پنل روی Workers و Pages — بدون ۱۱۰۱</div>
      </div>
      <div class="spacer"></div>
      <span class="chip hide-sm" id="accountChip">${I.server} حساب انتخاب نشده</span>
      <button class="icon-btn" id="helpBtn" type="button" title="راهنمای کامل" aria-label="راهنما">${I.shield}</button>
    </div>
  </header>

  <div class="wrap">
    <main>
      <section class="card">
        <div class="card-head">${I.key} <b>توکن کلادفلر</b><span class="spacer"></span><span class="chip neon" id="tokenState">${I.shield} ذخیره نشده</span></div>
        <div class="card-body">
          <p class="hint">توکن API با دسترسی <b>Workers Scripts:Edit</b>، <b>Pages:Edit</b>، <b>KV:Edit</b> و در صورت نیاز <b>D1:Edit</b>. توکن فقط در حافظهٔ همین تب مرورگر می‌ماند و روی سرور ذخیره نمی‌شود.</p>
          <div class="row">
            <div class="field" style="flex:1">
              <label for="token">API Token</label>
              <input id="token" type="password" placeholder="cf_..." autocomplete="off" spellcheck="false">
            </div>
            <div class="field">
              <label for="account">حساب</label>
              <select id="account"><option value="">— ابتدا توکن را وارد کن —</option></select>
            </div>
          </div>
          <div class="row">
            <button class="btn" type="button" id="loadAccounts">${I.refresh} دریافت حساب‌ها</button>
            <button class="btn ghost" type="button" id="clearToken">${I.close} پاک کردن توکن</button>
            <a class="btn neon" href="${TOKEN_URL}" target="_blank" rel="noopener noreferrer">${I.key} ساخت خودکار توکن</a>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-head">${I.upload} <b>منبع پروژه</b><span class="spacer"></span><span class="chip" id="sourceChip">${I.layers} —</span></div>
        <div class="card-body">
          <div class="tabs" id="sourceTabs">
            <button class="tab is-active" type="button" data-src="zip">${I.zip} زیپ پروژه</button>
            <button class="tab" type="button" data-src="file">${I.file} فایل ورکر</button>
            <button class="tab" type="button" data-src="url">${I.globe} آدرس آنلاین</button>
            <button class="tab" type="button" data-src="github">${I.github} گیت‌هاب</button>
          </div>

          <div class="pane is-active" data-pane="zip">
            <div class="drop" id="dropZip">
              ${I.zip}
              <b>زیپ پروژه را این‌جا رها کن</b>
              <small>یا کلیک کن — سقف ۱۲ مگابایت</small>
            </div>
            <input type="file" id="fileZip" accept=".zip" hidden>
          </div>

          <div class="pane" data-pane="file">
            <div class="drop" id="dropFile">
              ${I.file}
              <b>فایل ورکر را انتخاب کن</b>
              <small>worker.js / _worker.js / index.mjs</small>
            </div>
            <input type="file" id="fileJs" accept=".js,.mjs,.cjs,.txt" hidden>
          </div>

          <div class="pane" data-pane="url">
            <div class="field">
              <label for="urlInput">آدرس فایل یا زیپ</label>
              <input id="urlInput" type="url" placeholder="https://raw.githubusercontent.com/user/repo/main/worker.js">
            </div>
            <p class="hint">آدرس‌های خصوصی مثل <span class="kbd">localhost</span> و <span class="kbd">192.168.*</span> رد می‌شوند.</p>
          </div>

          <div class="pane" data-pane="github">
            <div class="row">
              <div class="field">
                <label for="repoInput">مخزن</label>
                <input id="repoInput" type="text" placeholder="owner/repo یا https://github.com/owner/repo">
              </div>
              <div class="field">
                <label for="branchInput">برنچ</label>
                <input id="branchInput" type="text" placeholder="main (خالی = پیش‌فرض)">
              </div>
            </div>
            <div class="field">
              <label for="ghToken">توکن گیت‌هاب (فقط برای مخزن خصوصی)</label>
              <input id="ghToken" type="password" placeholder="ghp_..." autocomplete="off">
            </div>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-head">${I.radar || I.layers} <b>پیش‌نمایش تشخیص</b><span class="spacer"></span><button class="btn" type="button" id="inspectBtn">${I.layers} تحلیل پروژه</button></div>
        <div class="card-body" id="previewBody">
          <p class="hint" id="previewEmpty">هنوز چیزی تحلیل نشده. منبع را انتخاب کن و «تحلیل پروژه» را بزن.</p>
          <div id="previewContent" hidden>
            <div class="preview-grid" id="previewGrid"></div>
            <ul class="warn-list" id="previewWarnings"></ul>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-head">${I.bolt} <b>تنظیمات استقرار</b></div>
        <div class="card-body">
          <div class="row">
            <div class="field">
              <label for="nameInput">نام اسکریپت / پروژه</label>
              <input id="nameInput" type="text" placeholder="my-panel">
            </div>
            <div class="field">
              <label for="modeSelect">مقصد</label>
              <select id="modeSelect">
                <option value="worker">Cloudflare Workers</option>
                <option value="pages">Cloudflare Pages</option>
              </select>
            </div>
            <div class="field">
              <label for="compatInput">compatibility_date</label>
              <input id="compatInput" type="text" value="2024-11-06">
            </div>
          </div>
          <label class="ok-line" style="cursor:pointer">
            <input type="checkbox" id="createD1"> ساخت خودکار دیتابیس D1 + اجرای schema.sql (اگر پروژه داشته باشد)
          </label>
          <label class="ok-line" style="cursor:pointer">
            <input type="checkbox" id="createKV"> ساخت یا وصل کردن فضای KV (binding با نام KV)
          </label>
          <div class="row" id="kvRow" hidden>
            <div class="field">
              <label for="kvSelect">فضای KV موجود</label>
              <select id="kvSelect"><option value="">— ساخت فضای جدید —</option></select>
            </div>
            <div class="field">
              <label for="kvNameInput">نام فضای جدید (اگر ساخت را انتخاب کردی)</label>
              <input id="kvNameInput" type="text" placeholder="my-panel-kv">
            </div>
          </div>
          <label class="ok-line" style="cursor:pointer">
            <input type="checkbox" id="obfuscate" checked> مبهم‌سازی منحصربه‌فرد این استقرار (بذر تصادفی + اثر انگشت)
          </label>
          <button class="btn primary" type="button" id="deployBtn">${I.bolt} استقرار روی کلادفلر</button>
        </div>
      </section>

      <section class="card">
        <div class="card-head">${I.terminal} <b>کنسول استقرار</b><span class="spacer"></span><span class="chip" id="deployState">آماده</span></div>
        <div class="card-body">
          <div class="console" id="console"><span class="idle">در انتظار شروع استقرار…</span></div>
          <div id="resultBox" hidden></div>
        </div>
      </section>

      <section class="card">
        <div class="card-head">${I.clock} <b>تاریخچهٔ این مرورگر</b><span class="spacer"></span><button class="btn ghost" type="button" id="clearHistory">${I.trash} پاک کردن</button></div>
        <div class="card-body">
          <table class="hist">
            <thead><tr><th>نام</th><th>مقصد</th><th>آدرس</th><th>زمان</th><th></th></tr></thead>
            <tbody id="historyBody"><tr><td colspan="5" class="empty">هنوز استقراری ثبت نشده</td></tr></tbody>
          </table>
        </div>
      </section>
    </main>

    <footer class="foot">
      <a class="foot-link" href="https://t.me/miliconfig" target="_blank" rel="noopener noreferrer">${I.telegram} کانال پشتیبانی miliconfig</a>
      <a class="foot-link sponsor" href="https://t.me/cynetx" target="_blank" rel="noopener noreferrer">${I.heart} اسپانسر: <span dir="ltr">@cynetx</span></a>
      <span class="foot-note">بدون ذخیرهٔ توکن · بدون دیتابیس · توکن فقط در همین تب</span>
    </footer>
  </div>

  <div class="modal" id="helpModal" role="dialog" aria-modal="true">
    <div class="modal-card help-card">
      <div class="modal-head"><b>${I.shield} راهنمای استقراردهنده</b><button class="icon-btn" type="button" data-close="helpModal">${I.close}</button></div>
      <div class="help-tabs">
        <button class="help-tab is-active" type="button" data-help="start">شروع سریع</button>
        <button class="help-tab" type="button" data-help="source">منابع</button>
        <button class="help-tab" type="button" data-help="detect">تشخیص</button>
        <button class="help-tab" type="button" data-help="deploy">استقرار</button>
        <button class="help-tab" type="button" data-help="err1101">خطای ۱۱۰۱</button>
        <button class="help-tab" type="button" data-help="d1">دیتابیس D1</button>
        <button class="help-tab" type="button" data-help="fix">عیب‌یابی</button>
      </div>
      <div class="help-body">
        <section class="help-pane is-active" data-help-pane="start">
          <h4>${I.bolt} سه قدم تا پنل زنده</h4>
          <ul>
            <li>دکمهٔ «ساخت خودکار توکن» را بزن؛ توکن با مجوزهای لازم از پیش انتخاب شده ساخته می‌شود. آن را کپی کن و در فیلد API Token بگذار، بعد «دریافت حساب‌ها» را بزن.</li>
            <li>منبع پروژه را انتخاب کن (زیپ، فایل، آدرس یا گیت‌هاب) و «تحلیل پروژه» را بزن.</li>
            <li>نام و مقصد را تأیید کن و «استقرار» را بزن؛ آدرس نهایی پایین کنسول می‌آید.</li>
          </ul>
          <p>این ابزار هیچ توکنی را ذخیره نمی‌کند؛ با بستن تب، همه‌چیز از حافظه پاک می‌شود. اگر جایی گیر کردی، در کانال پشتیبانی miliconfig بپرس.</p>
        </section>
        <section class="help-pane" data-help-pane="source">
          <h4>${I.layers} چه چیزی می‌توانی بدهی</h4>
          <ul>
            <li><b>زیپ:</b> کل پروژه؛ فایل ورکر خودکار پیدا می‌شود.</li>
            <li><b>فایل:</b> یک <span class="kbd">worker.js</span> یا <span class="kbd">_worker.js</span>.</li>
            <li><b>آدرس:</b> لینک خام فایل یا زیپ (مثل raw.githubusercontent.com).</li>
            <li><b>گیت‌هاب:</b> <span class="kbd">owner/repo</span> + برنچ؛ برای مخزن خصوصی توکن گیت‌هاب بده.</li>
          </ul>
        </section>
        <section class="help-pane" data-help-pane="detect">
          <h4>${I.copy} تشخیص خودکار</h4>
          <ul>
            <li><b>wrangler.toml:</b> نام، فایل اصلی و bindingها خوانده می‌شوند.</li>
            <li><b>_worker.js:</b> پروژهٔ Pages با Functions.</li>
            <li><b>index.html:</b> پروژهٔ استاتیک Pages.</li>
            <li><b>export default:</b> ورکر ماژولار؛ <b>addEventListener</b>: ورکر کلاسیک.</li>
          </ul>
          <p>هر تشخیص همراه هشدارهایش نشان داده می‌شود؛ اگر ورودی اشتباه بود، در فیلد نام/فایل اصلاح کن.</p>
        </section>
        <section class="help-pane" data-help-pane="deploy">
          <h4>${I.server} پشت صحنهٔ استقرار</h4>
          <ul>
            <li>نسخهٔ فعال پیش از هر استقرار نوسازی می‌شود تا نسخهٔ ناسالم باقی نماند.</li>
            <li>metadata و ماژول‌ها یک‌جا و با نوع محتوای درست آپلود می‌شوند.</li>
            <li>آدرس <span class="kbd">workers.dev</span> فعال و چند بار تست سلامت می‌شود.</li>
            <li>اگر پاسخ سالم نبود، استقرار یک‌بار به‌صورت خودکار تکرار می‌شود.</li>
            <li>هر استقرار با بذر تصادفی مهر می‌خورد، کد مردهٔ یکتا می‌گیرد و یک <span class="kbd">fingerprint</span> دارد؛ دو استقرار از یک پروژه خروجی یکسان ندارند.</li>
          </ul>
        </section>
        <section class="help-pane" data-help-pane="err1101">
          <h4>${I.warning} چرا ۱۱۰۱ می‌گیریم</h4>
          <ul>
            <li><span class="kbd">main_module</span> با نام فایل ماژول هم‌خوان نیست.</li>
            <li><b>binding معیوب:</b> شناسهٔ D1 ناموجود یا KV بدون namespace.</li>
            <li><span class="kbd">compatibility_date</span> نامعتبر.</li>
          </ul>
          <p>این ابزار همهٔ این موارد را پیش از استقرار بررسی می‌کند و بعد از آپلود، سلامت آدرس را چند بار می‌سنجد.</p>
        </section>
        <section class="help-pane" data-help-pane="d1">
          <h4>${I.layers} دیتابیس D1 و فضای KV</h4>
          <ul>
            <li>تیک «ساخت خودکار D1» را بزن تا دیتابیس با نام پروژه ساخته شود.</li>
            <li>اگر فایل <span class="kbd">schema.sql</span> کنار پروژه باشد، خودکار اجرا می‌شود.</li>
            <li>binding با نام <span class="kbd">DB</span> به اسکریپت وصل می‌شود.</li>
            <li><b>KV:</b> با تیک «ساخت یا وصل کردن KV» می‌توانی فضای موجود را انتخاب کنی یا فضای تازه بسازی؛ binding با نام <span class="kbd">KV</span> وصل می‌شود.</li>
            <li>bindingهای KV یا D1 بدون شناسه، رایج‌ترین دلیل خطای ۱۱۰۱ هستند.</li>
          </ul>
        </section>
        <section class="help-pane" data-help-pane="fix">
          <h4>${I.terminal} عیب‌یابی سریع</h4>
          <ul>
            <li><b>۱۰۰۰۷:</b> توکن به حساب دسترسی ندارد؛ حساب را دوباره انتخاب کن.</li>
            <li><b>۱۰۰۲۱:</b> نام تکراری است؛ نام دیگری بگذار یا حذفش کن.</li>
            <li><b>آدرس بالا نمی‌آید:</b> ۱۰ ثانیه صبر و «تست دوباره» بزن.</li>
            <li><b>صفحهٔ سفید:</b> ورودی اشتباه است؛ فایل ورکر را دستی انتخاب کن.</li>
          </ul>
        </section>
      </div>
      <div class="modal-foot">
        <button class="btn primary" type="button" data-close="helpModal">${I.check} فهمیدم</button>
        <a class="btn ghost" href="https://t.me/miliconfig" target="_blank" rel="noopener noreferrer">${I.telegram} پشتیبانی</a>
        <label class="help-check"><input type="checkbox" id="helpNoAuto"> دیگر خودکار باز نشود</label>
      </div>
    </div>
  </div>

  <div class="modal" id="confirmModal" role="dialog" aria-modal="true">
    <div class="modal-card">
      <div class="modal-head"><b>${I.warning} تأیید حذف</b><button class="icon-btn" type="button" data-close="confirmModal">${I.close}</button></div>
      <div class="card-body" style="padding:15px"><p class="hint" id="confirmText">مطمئنی؟</p></div>
      <div class="modal-foot">
        <button class="btn danger" type="button" id="confirmYes">${I.trash} حذف کن</button>
        <button class="btn ghost" type="button" data-close="confirmModal">انصراف</button>
      </div>
    </div>
  </div>

  <div class="toast" id="toast"></div>

<script>
  var ICO = ${ICON_JSON};
  var ORIGIN = ${JSON.stringify(origin)};
  var state = { token: '', accounts: [], accountId: '', sourceTab: 'zip', source: null, detection: null, busy: false, pendingDelete: null };

  function $(id) { return document.getElementById(id); }
  function toast(text, kind) {
    var t = $('toast');
    t.textContent = text;
    t.className = 'toast show' + (kind === 'err' ? ' err' : '');
    clearTimeout(t._t);
    t._t = setTimeout(function () { t.className = 'toast'; }, 3200);
  }
  function api(path, body, method) {
    var headers = { 'Content-Type': 'application/json' };
    if (state.token) headers['x-cf-token'] = state.token;
    if (state.accountId) headers['x-cf-account'] = state.accountId;
    return fetch(path, { method: method || (body ? 'POST' : 'GET'), headers: headers, body: body ? JSON.stringify(body) : undefined })
      .then(function (res) { return res.json(); });
  }
  function saveToken() {
    try { sessionStorage.setItem('cfd_token', state.token); } catch (e) {}
    $('tokenState').textContent = state.token ? 'در حافظهٔ این تب' : 'ذخیره نشده';
  }
  function loadToken() {
    try { state.token = sessionStorage.getItem('cfd_token') || ''; } catch (e) { state.token = ''; }
    $('token').value = state.token;
    saveToken();
  }

  // ——— تب‌های منبع ———
  function setSourceTab(name) {
    state.sourceTab = name;
    document.querySelectorAll('[data-src]').forEach(function (b) { b.classList.toggle('is-active', b.getAttribute('data-src') === name); });
    document.querySelectorAll('.pane').forEach(function (p) { p.classList.toggle('is-active', p.getAttribute('data-pane') === name); });
  }
  document.querySelectorAll('[data-src]').forEach(function (b) {
    b.addEventListener('click', function () { setSourceTab(b.getAttribute('data-src')); });
  });

  function readFile(file, asText) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(reader.result); };
      reader.onerror = function () { reject(new Error('خواندن فایل ناموفق بود')); };
      if (asText) reader.readAsText(file, 'utf-8'); else reader.readAsDataURL(file);
    });
  }

  function prepareZip(file) {
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) return toast('حجم زیپ بیشتر از ۱۲ مگابایت است', 'err');
    readFile(file, false).then(function (dataUrl) {
      state.source = { type: 'zip', name: file.name, base64: String(dataUrl).split(',')[1] || '' };
      $('sourceChip').textContent = file.name + ' · ' + Math.round(file.size / 1024) + ' KB';
      toast('زیپ آماده شد؛ حالا «تحلیل پروژه» را بزن');
    }).catch(function () { toast('خواندن زیپ ناموفق بود', 'err'); });
  }
  function prepareFile(file) {
    if (!file) return;
    readFile(file, true).then(function (text) {
      state.source = { type: 'text', name: file.name, content: text };
      $('sourceChip').textContent = file.name + ' · ' + Math.round(file.size / 1024) + ' KB';
      toast('فایل آماده شد؛ حالا «تحلیل پروژه» را بزن');
    }).catch(function () { toast('خواندن فایل ناموفق بود', 'err'); });
  }

  ['dropZip', 'fileZip'].forEach(function (id) {
    var el = $(id);
    if (id === 'dropZip') {
      el.addEventListener('click', function () { $('fileZip').click(); });
      ['dragenter', 'dragover'].forEach(function (ev) { el.addEventListener(ev, function (e) { e.preventDefault(); el.classList.add('is-over'); }); });
      ['dragleave', 'drop'].forEach(function (ev) { el.addEventListener(ev, function (e) { e.preventDefault(); el.classList.remove('is-over'); }); });
      el.addEventListener('drop', function (e) { prepareZip(e.dataTransfer.files[0]); });
    } else {
      el.addEventListener('change', function () { prepareZip(el.files[0]); });
    }
  });
  $('dropFile').addEventListener('click', function () { $('fileJs').click(); });
  $('fileJs').addEventListener('change', function () { prepareFile($('fileJs').files[0]); });
  $('dropFile').addEventListener('dragover', function (e) { e.preventDefault(); $('dropFile').classList.add('is-over'); });
  $('dropFile').addEventListener('dragleave', function () { $('dropFile').classList.remove('is-over'); });
  $('dropFile').addEventListener('drop', function (e) { e.preventDefault(); $('dropFile').classList.remove('is-over'); prepareFile(e.dataTransfer.files[0]); });

  function currentSource() {
    if (state.sourceTab === 'url') {
      var url = $('urlInput').value.trim();
      if (!url) { toast('آدرس را وارد کن', 'err'); return null; }
      return { type: 'url', url: url };
    }
    if (state.sourceTab === 'github') {
      var repo = $('repoInput').value.trim();
      if (!repo) { toast('مخزن را وارد کن', 'err'); return null; }
      return { type: 'github', repo: repo, branch: $('branchInput').value.trim(), token: $('ghToken').value.trim() };
    }
    if (!state.source) { toast('اول فایل یا زیپ را انتخاب کن', 'err'); return null; }
    return state.source;
  }

  // ——— تحلیل ———
  $('inspectBtn').addEventListener('click', function () {
    var source = currentSource();
    if (!source) return;
    $('inspectBtn').disabled = true;
    $('previewEmpty').textContent = 'در حال خواندن و تحلیل…';
    api('/api/inspect', { source: source, options: { name: $('nameInput').value.trim() } })
      .then(function (data) {
        if (!data.success) throw new Error(data.message || 'تحلیل ناموفق بود');
        state.detection = data.detection;
        $('nameInput').value = data.detection.name;
        $('compatInput').value = data.detection.compatibilityDate || '2024-11-06';
        $('modeSelect').value = data.detection.mode;
        $('previewEmpty').hidden = true;
        $('previewContent').hidden = false;
        var grid = $('previewGrid');
        grid.innerHTML = '';
        var items = [
          ['نوع', data.detection.kind],
          ['مقصد', data.detection.mode === 'pages' ? 'Pages' : 'Workers'],
          ['فایل ورودی', data.detection.mainFile || 'استاتیک'],
          ['تعداد فایل', data.detection.fileCount],
          ['حجم', Math.round(data.detection.sizeBytes / 1024) + ' KB'],
          ['منبع', data.origin],
          ['schema.sql', data.detection.hasSchema ? 'دارد' : 'ندارد'],
          ['binding', (data.detection.bindings || []).map(function (b) { return b.name; }).join('، ') || '—']
        ];
        items.forEach(function (pair) {
          var box = document.createElement('div');
          box.className = 'kv';
          var s = document.createElement('span'); s.textContent = pair[0];
          var b = document.createElement('b'); b.textContent = String(pair[1]);
          box.appendChild(s); box.appendChild(b);
          grid.appendChild(box);
        });
        var list = $('previewWarnings');
        list.innerHTML = '';
        (data.detection.warnings || []).forEach(function (w) {
          var li = document.createElement('li'); li.textContent = w; list.appendChild(li);
        });
        toast('تحلیل کامل شد');
      })
      .catch(function (err) { $('previewEmpty').hidden = false; $('previewEmpty').textContent = err.message; toast(err.message, 'err'); })
      .then(function () { $('inspectBtn').disabled = false; });
  });

  // ——— کنسول ———
  function logLine(level, text, delay) {
    var box = $('console');
    if (box.querySelector('.idle')) box.innerHTML = '';
    setTimeout(function () {
      var line = document.createElement('div');
      line.className = 'log ' + level;
      var dot = document.createElement('i');
      var span = document.createElement('span');
      span.textContent = text;
      line.appendChild(dot); line.appendChild(span);
      box.appendChild(line);
      box.scrollTop = box.scrollHeight;
    }, delay || 0);
  }

  function pollHealth(url, attempt) {
    attempt = attempt || 0;
    if (attempt > 11) {
      $('deployState').textContent = 'در حال انتشار';
      return logLine('warn', 'آدرس هنوز آماده نشده؛ چند ثانیه بعد صفحه را دوباره باز کن');
    }
    setTimeout(function () {
      api('/api/health', { url: url }).then(function (res) {
        if (res && res.success && res.health && res.health.ok) {
          logLine('ok', 'پنل آنلاین شد (HTTP ' + res.health.status + ')');
          $('deployState').textContent = 'آنلاین';
          return;
        }
        logLine('step', 'در حال انتشار… (تلاش ' + (attempt + 1) + ')');
        pollHealth(url, attempt + 1);
      }).catch(function () { pollHealth(url, attempt + 1); });
    }, 5000);
  }

  function renderResult(data) {
    var box = $('resultBox');
    box.hidden = false;
    box.innerHTML = '';
    var wrap = document.createElement('div');
    wrap.className = 'result' + (data.success ? '' : ' bad');
    var title = document.createElement('div');
    title.className = 'ok-line';
    title.textContent = data.message || (data.success ? 'موفق' : 'ناموفق');
    wrap.appendChild(title);
    if (data.fingerprint) {
      var fp = document.createElement('div');
      fp.className = 'hint';
      fp.style.fontFamily = 'var(--mono)';
      fp.style.direction = 'ltr';
      fp.style.textAlign = 'left';
      fp.textContent = 'fingerprint: ' + data.fingerprint;
      wrap.appendChild(fp);
    }
    if (data.url) {
      var urlBox = document.createElement('div');
      urlBox.className = 'url-box';
      urlBox.textContent = data.url;
      wrap.appendChild(urlBox);
      var acts = document.createElement('div');
      acts.style.display = 'flex';
      acts.style.gap = '8px';
      acts.style.flexWrap = 'wrap';
      var open = document.createElement('a');
      open.className = 'btn primary'; open.href = data.url; open.target = '_blank'; open.rel = 'noopener';
      open.innerHTML = ICO.external + ' باز کردن پنل';
      var copy = document.createElement('button');
      copy.className = 'btn'; copy.type = 'button'; copy.innerHTML = ICO.copy + ' کپی آدرس';
      copy.addEventListener('click', function () { navigator.clipboard.writeText(data.url).then(function () { toast('کپی شد'); }); });
      var again = document.createElement('button');
      again.className = 'btn ghost'; again.type = 'button'; again.innerHTML = ICO.refresh + ' تست دوباره';
      again.addEventListener('click', function () { window.open(data.url, '_blank'); });
      acts.appendChild(open); acts.appendChild(copy); acts.appendChild(again);
      wrap.appendChild(acts);
    }
    box.appendChild(wrap);
  }

  $('deployBtn').addEventListener('click', function () {
    if (state.busy) return;
    var source = currentSource();
    if (!source) return;
    if (!state.token) return toast('اول توکن API را وارد کن', 'err');
    if (!state.accountId) return toast('حساب کلادفلر را انتخاب کن', 'err');
    var name = $('nameInput').value.trim();
    if (!name) return toast('نام اسکریپت را وارد کن', 'err');

    state.busy = true;
    $('deployBtn').disabled = true;
    $('deployState').textContent = 'در حال استقرار…';
    $('resultBox').hidden = true;
    $('console').innerHTML = '';

    var options = {
      name: name,
      accountId: state.accountId,
      mode: $('modeSelect').value,
      compatibilityDate: $('compatInput').value.trim() || '2024-11-06',
      createD1: $('createD1').checked,
      obfuscate: $('obfuscate') ? $('obfuscate').checked : true,
      createKV: $('createKV').checked,
      kvNamespaceId: $('kvSelect') ? $('kvSelect').value : '',
      kvName: $('kvNameInput') ? $('kvNameInput').value.trim() : '',
      bindings: state.detection ? state.detection.bindings : []
    };
    logLine('step', 'ارسال درخواست استقرار…', 0);
    api('/api/deploy', { source: source, options: options }).then(function (data) {
      (data.steps || []).forEach(function (step, idx) { logLine(step.level || 'step', step.text, 90 * (idx + 1)); });
      setTimeout(function () {
        renderResult(data);
        $('deployState').textContent = data.success ? 'موفق' : 'ناموفق';
        toast(data.message || (data.success ? 'استقرار انجام شد' : 'استقرار ناموفق'), data.success ? '' : 'err');
        if (data.success && data.url) addHistory({ name: data.name || name, mode: data.mode || options.mode, url: data.url, at: Date.now() });
        if (data.pending && data.url) pollHealth(data.url, 0);
      }, 90 * ((data.steps || []).length + 1));
    }).catch(function (err) {
      logLine('err', 'خطا: ' + err.message, 0);
      $('deployState').textContent = 'ناموفق';
      toast('خطای شبکه در استقرار', 'err');
    }).then(function () {
      state.busy = false;
      $('deployBtn').disabled = false;
    });
  });

  // ——— حساب‌ها ———
  function renderAccounts(list) {
    var select = $('account');
    select.innerHTML = '';
    if (!list.length) {
      var opt = document.createElement('option');
      opt.value = ''; opt.textContent = 'حسابی پیدا نشد';
      select.appendChild(opt);
      return;
    }
    list.forEach(function (acc, idx) {
      var o = document.createElement('option');
      o.value = acc.id;
      o.textContent = acc.name;
      select.appendChild(o);
      if (idx === 0) state.accountId = acc.id;
    });
    select.value = state.accountId;
    var chip = $('accountChip');
    chip.innerHTML = ICO.server + ' ' + (list.find(function (a) { return a.id === state.accountId; }) || {}).name;
  }
  function loadAccounts() {
    if (!state.token) return toast('اول توکن را وارد کن', 'err');
    $('loadAccounts').disabled = true;
    api('/api/accounts').then(function (data) {
      if (!data.success) throw new Error(data.message || 'دریافت حساب‌ها ناموفق بود');
      state.accounts = data.accounts || [];
      renderAccounts(state.accounts);
      toast(state.accounts.length ? 'حساب‌ها دریافت شد' : 'هیچ حسابی پیدا نشد', state.accounts.length ? '' : 'err');
    }).catch(function (err) { toast(err.message, 'err'); })
      .then(function () { $('loadAccounts').disabled = false; });
  }
  $('loadAccounts').addEventListener('click', function () { state.token = $('token').value.trim(); saveToken(); loadAccounts(); });
  $('token').addEventListener('change', function () { state.token = $('token').value.trim(); saveToken(); });
  $('account').addEventListener('change', function () {
    state.accountId = $('account').value;
    var chip = $('accountChip');
    var acc = state.accounts.find(function (a) { return a.id === state.accountId; });
    chip.innerHTML = ICO.server + ' ' + (acc ? acc.name : 'حساب انتخاب نشده');
  });
  // ——— KV: نمایش و بارگیری فضاهای موجود ———
  $('createKV').addEventListener('change', function () {
    var on = $('createKV').checked;
    $('kvRow').hidden = !on;
    if (on && $('kvSelect').options.length <= 1 && state.accountId) {
      api('/api/kv-namespaces?account=' + encodeURIComponent(state.accountId)).then(function (data) {
        if (!data.success) return;
        (data.namespaces || []).forEach(function (ns) {
          var o = document.createElement('option');
          o.value = ns.id;
          o.textContent = ns.title || ns.id;
          $('kvSelect').appendChild(o);
        });
      }).catch(function () {});
    }
  });

  $('clearToken').addEventListener('click', function () {
    state.token = ''; state.accounts = []; state.accountId = '';
    $('token').value = ''; saveToken();
    $('account').innerHTML = '<option value="">— ابتدا توکن را وارد کن —</option>';
    $('accountChip').innerHTML = ICO.server + ' حساب انتخاب نشده';
    try { sessionStorage.removeItem('cfd_token'); } catch (e) {}
    toast('توکن از حافظه پاک شد');
  });

  // ——— تاریخچه (localStorage) ———
  // نام history در مرورگر رزرو است (window.history)؛ از readHistory استفاده می‌کنیم
  function readHistory() {
    try { return JSON.parse(localStorage.getItem('cfd_history') || '[]'); } catch (e) { return []; }
  }
  function addHistory(item) {
    var list = readHistory().filter(function (x) { return !(x.name === item.name && x.mode === item.mode); });
    list.unshift(item);
    try { localStorage.setItem('cfd_history', JSON.stringify(list.slice(0, 20))); } catch (e) {}
    renderHistory();
  }
  function renderHistory() {
    var body = $('historyBody');
    var list = readHistory();
    body.innerHTML = '';
    if (!list.length) {
      body.innerHTML = '<tr><td colspan="5" class="empty">هنوز استقراری ثبت نشده</td></tr>';
      return;
    }
    list.forEach(function (item, idx) {
      var tr = document.createElement('tr');
      var td1 = document.createElement('td'); td1.textContent = item.name;
      var td2 = document.createElement('td'); td2.textContent = item.mode === 'pages' ? 'Pages' : 'Workers';
      var td3 = document.createElement('td'); td3.className = 'mono'; td3.textContent = item.url;
      var td4 = document.createElement('td'); td4.textContent = new Date(item.at).toLocaleString('fa-IR');
      var td5 = document.createElement('td');
      var open = document.createElement('a'); open.className = 'btn ghost'; open.href = item.url; open.target = '_blank'; open.rel = 'noopener'; open.innerHTML = ICO.external;
      var del = document.createElement('button'); del.className = 'btn danger'; del.type = 'button'; del.innerHTML = ICO.trash;
      del.addEventListener('click', function () { askDelete(item); });
      td5.appendChild(open); td5.appendChild(del);
      tr.appendChild(td1); tr.appendChild(td2); tr.appendChild(td3); tr.appendChild(td4); tr.appendChild(td5);
      body.appendChild(tr);
    });
  }
  function askDelete(item) {
    state.pendingDelete = item;
    $('confirmText').textContent = 'استقرار «' + item.name + '» از حساب کلادفلر حذف شود؟ این کار برگشت‌پذیر نیست.';
    $('confirmModal').classList.add('is-open');
  }
  $('confirmYes').addEventListener('click', function () {
    var item = state.pendingDelete;
    if (!item) return;
    api('/api/delete', { accountId: state.accountId, name: item.name, mode: item.mode }).then(function (data) {
      if (!data.success) throw new Error(data.message || 'حذف ناموفق بود');
      var list = readHistory().filter(function (x) { return !(x.name === item.name && x.mode === item.mode); });
      try { localStorage.setItem('cfd_history', JSON.stringify(list)); } catch (e) {}
      renderHistory();
      $('confirmModal').classList.remove('is-open');
      toast('حذف شد');
    }).catch(function (err) { toast(err.message, 'err'); });
  });
  $('clearHistory').addEventListener('click', function () {
    try { localStorage.removeItem('cfd_history'); } catch (e) {}
    renderHistory();
    toast('تاریخچه پاک شد');
  });

  // ——— مودال‌ها و راهنما ———
  document.querySelectorAll('[data-close]').forEach(function (b) {
    b.addEventListener('click', function () { $(b.getAttribute('data-close')).classList.remove('is-open'); });
  });
  document.querySelectorAll('.modal').forEach(function (m) {
    m.addEventListener('click', function (e) { if (e.target === m) m.classList.remove('is-open'); });
  });
  function switchHelp(id) {
    document.querySelectorAll('[data-help]').forEach(function (b) { b.classList.toggle('is-active', b.getAttribute('data-help') === id); });
    document.querySelectorAll('[data-help-pane]').forEach(function (p) { p.classList.toggle('is-active', p.getAttribute('data-help-pane') === id); });
    var body = document.querySelector('.help-body');
    if (body) body.scrollTop = 0;
  }
  document.querySelectorAll('[data-help]').forEach(function (b) {
    b.addEventListener('click', function () { switchHelp(b.getAttribute('data-help')); });
  });
  function openHelp() { switchHelp('start'); $('helpModal').classList.add('is-open'); }
  $('helpBtn').addEventListener('click', openHelp);

  document.addEventListener('pointerdown', function (e) {
    var host = e.target.closest('.btn, .icon-btn, .tab, .help-tab');
    if (!host || host.disabled) return;
    var rect = host.getBoundingClientRect();
    var wave = document.createElement('span');
    wave.className = 'ripple';
    wave.style.left = (e.clientX - rect.left) + 'px';
    wave.style.top = (e.clientY - rect.top) + 'px';
    host.appendChild(wave);
    setTimeout(function () { if (wave.parentNode) wave.parentNode.removeChild(wave); }, 620);
  }, { passive: true });

  loadToken();
  renderHistory();
  var noAuto = $('helpNoAuto');
  var skipHelp = false;
  try { skipHelp = localStorage.getItem('cfd_help_off') === '1'; } catch (e) {}
  if (noAuto) {
    noAuto.checked = skipHelp;
    noAuto.addEventListener('change', function () {
      try { localStorage.setItem('cfd_help_off', noAuto.checked ? '1' : '0'); } catch (e) {}
    });
  }
  if (!skipHelp) {
    setTimeout(function () {
      if (document.querySelector('.modal.is-open')) return;
      openHelp();
    }, 2000);
  }
</script>
</body>
</html>`;
}
