// ============================================================================
// cf-deployer — استقراردهندهٔ پنل/ورکر روی Cloudflare Workers و Pages
// • ورودی: زیپ، فایل، آدرس آنلاین یا مخزن گیت‌هاب
// • خروجی: استقرار سالم همراه با بازبینی پیش از آپلود و تست سلامت
// • هیچ توکنی روی سرور ذخیره نمی‌شود؛ توکن فقط در هدر هر درخواست می‌آید.
// ============================================================================

import { renderAppHtml } from './ui.js';
import { readZip, stripTopFolder } from './zip.js';
import { detectProject } from './detect.js';
import { fingerprint, obfuscateFiles, randomSeed } from './obfuscate.js';
import {
  CfError,
  cf,
  createD1,
  createKvNamespace,
  defaultSleep,
  deleteScript,
  deployPagesProject,
  enableWorkersDev,
  ensurePagesProject,
  getSubdomain,
  healthCheck,
  listAccounts,
  listKvNamespaces,
  normalizeBindings,
  runD1Schema,
  scriptExists,
  uploadWorkerScript
} from './cf.js';

const MAX_BODY = 12 * 1024 * 1024;

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'content-type, x-cf-token, x-cf-account',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
};

// هدرهای امنیتی سراسری: بدون کش، بدون اسنیف، بدون iframe، با CSP سخت
const SECURITY_HEADERS = {
  'Cache-Control': 'no-store, max-age=0',
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; " +
    "img-src data:; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
};

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', ...SECURITY_HEADERS, ...cors }
  });

const fail = (message, status = 400, extra = {}) => json({ success: false, message, ...extra }, status);

// ── اعتبارسنجی ورودی ──────────────────────────────────────────────────────
const ACCOUNT_RE = /^[a-f0-9]{32}$/i;
const TOKEN_RE = /^[A-Za-z0-9_\-]{20,200}$/;
const SLUG_RE = /^[a-z0-9][a-z0-9-]{0,53}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

const isAccountId = v => ACCOUNT_RE.test(String(v || '').trim());
const readToken = req => {
  const raw = String(req.headers.get('x-cf-token') || '').trim();
  if (raw && !TOKEN_RE.test(raw)) throw new CfError('توکن API معتبر نیست', { status: 401 });
  return raw;
};
const readAccount = v => {
  const id = String(v || '').trim();
  if (id && !isAccountId(id)) throw new CfError('شناسهٔ حساب کلادفلر معتبر نیست', { status: 400 });
  return id;
};

// محدودیت نرخ ساده در حافظهٔ ایزوله (ضد سوءاستفاده از API)
const RATE_LIMIT = 40;
const RATE_WINDOW = 10 * 60 * 1000;
const rateBuckets = new Map();
function allowRequest(ip) {
  const now = Date.now();
  const bucket = rateBuckets.get(ip) || { count: 0, reset: now + RATE_WINDOW };
  if (now > bucket.reset) { bucket.count = 0; bucket.reset = now + RATE_WINDOW; }
  bucket.count += 1;
  rateBuckets.set(ip, bucket);
  if (rateBuckets.size > 4000) {
    for (const [key, value] of rateBuckets) if (value.reset < now) rateBuckets.delete(key);
  }
  return bucket.count <= RATE_LIMIT;
}

// ── ضد SSRF ────────────────────────────────────────────────────────────────
const PRIVATE_HOST_RE = /(^|\.)(localhost|local|internal|home\.arpa|metadata|metadata\.google\.internal)$/i;
const IPV4_RE = /^\d{1,3}(\.\d{1,3}){3}$/;
const PRIVATE_IPV4_RE = /^(0\.|10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/;

function assertPublicUrl(raw) {
  let parsed;
  try { parsed = new URL(String(raw || '')); } catch (_e) { throw new CfError('آدرس معتبر نیست'); }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new CfError('فقط آدرس‌های http و https مجاز هستند');
  }
  if (parsed.username || parsed.password) throw new CfError('آدرس نباید نام کاربری/رمز داشته باشد');
  if (parsed.port && parsed.port !== '80' && parsed.port !== '443') {
    throw new CfError('پورت آدرس مجاز نیست');
  }
  const host = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (PRIVATE_HOST_RE.test(host)) throw new CfError('آدرس‌های داخلی/خصوصی مجاز نیستند');
  if (host === '::1' || host === '0.0.0.0' || host.startsWith('fc') || host.startsWith('fd') || host.startsWith('fe80')) {
    throw new CfError('آدرس‌های داخلی/خصوصی مجاز نیستند');
  }
  if (IPV4_RE.test(host)) throw new CfError('استفاده از آدرس IP مجاز نیست؛ دامنه بده');
  return parsed;
}

// ریدایرکت‌ها دستی دنبال می‌شوند تا هر مقصد دوباره اعتبارسنجی شود
async function safeFetch(raw, options = {}, hops = 0) {
  const url = assertPublicUrl(raw);
  const res = await fetch(url.toString(), { ...options, redirect: 'manual' });
  if (res.status >= 300 && res.status < 400) {
    if (hops >= 3) throw new CfError('تعداد ریدایرکت‌ها زیاد است');
    const location = res.headers.get('location');
    if (!location) throw new CfError('ریدایرکت نامعتبر است');
    return safeFetch(new URL(location, url).toString(), options, hops + 1);
  }
  return res;
}

function bytesToBase64(bytes) {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function base64ToBytes(text) {
  const clean = String(text || '').replace(/^data:[^;]+;base64,/, '').replace(/\s+/g, '');
  const binary = atob(clean);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

// ── منابع پروژه ────────────────────────────────────────────────────────────
async function resolveSource(source = {}) {
  const type = String(source.type || '').toLowerCase();

  if (type === 'text') {
    const content = String(source.content || '');
    if (!content.trim()) throw new CfError('محتوای فایل خالی است');
    const name = String(source.name || 'worker.js').replace(/[^\w.\-]/g, '') || 'worker.js';
    return { files: [{ path: name, data: new TextEncoder().encode(content) }], origin: 'فایل آپلودی' };
  }

  if (type === 'zip') {
    if (typeof source.base64 !== 'string' || !source.base64) throw new CfError('دادهٔ زیپ ارسال نشده است');
    if (source.base64.length > MAX_BODY * 1.4) throw new CfError('حجم زیپ بیشتر از سقف مجاز است', { status: 413 });
    const bytes = base64ToBytes(source.base64);
    if (bytes.length > MAX_BODY) throw new CfError('حجم زیپ بیشتر از سقف مجاز است', { status: 413 });
    const files = stripTopFolder(await readZip(bytes));
    return { files, origin: 'زیپ آپلودی' };
  }

  if (type === 'url') {
    const url = String(source.url || '').trim();
    if (!/^https?:\/\//i.test(url)) throw new CfError('آدرس باید با http یا https شروع شود');
    const res = await safeFetch(url, { headers: { 'User-Agent': 'cf-deployer/1.0', Accept: '*/*' } });
    if (!res.ok) throw new CfError('دانلود منبع ناموفق بود (HTTP ' + res.status + ')');
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (bytes.length > MAX_BODY) throw new CfError('حجم منبع بیشتر از سقف مجاز است', { status: 413 });
    const isZip = /\.zip(\?|$)/i.test(url) || (res.headers.get('content-type') || '').includes('zip') ||
      (bytes[0] === 0x50 && bytes[1] === 0x4b);
    if (isZip) return { files: stripTopFolder(await readZip(bytes)), origin: 'آدرس آنلاین (زیپ)' };
    const name = (url.split('?')[0].split('/').pop() || 'worker.js');
    return { files: [{ path: name, data: bytes }], origin: 'آدرس آنلاین (فایل)' };
  }

  if (type === 'github') {
    const raw = String(source.repo || '').trim();
    const match = raw.match(/github\.com\/([^/]+)\/([^/#?]+)/i) || raw.match(/^([\w.-]+)\/([\w.-]+)$/);
    if (!match) throw new CfError('آدرس مخزن گیت‌هاب معتبر نیست');
    const owner = match[1];
    const repo = match[2].replace(/\.git$/, '');
    const branch = String(source.branch || '').trim() || 'HEAD';
    const headers = { Accept: 'application/vnd.github+json', 'User-Agent': 'cf-deployer/1.0' };
    if (source.token) headers.Authorization = 'Bearer ' + String(source.token).replace(/[^\w.\-]/g, '');
    for (const part of [owner, repo]) {
      if (!/^[\w.-]{1,100}$/.test(part)) throw new CfError('نام مالک یا مخزن معتبر نیست');
    }
    const res = await safeFetch('https://api.github.com/repos/' + owner + '/' + repo + '/zipball/' + encodeURIComponent(branch), { headers });
    if (!res.ok) {
      throw new CfError(res.status === 404 ? 'مخزن یا برنچ پیدا نشد (برای ریپوی خصوصی توکن گیت‌هاب لازم است)' : 'دریافت زیپ از گیت‌هاب ناموفق بود (HTTP ' + res.status + ')');
    }
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (bytes.length > MAX_BODY) throw new CfError('حجم مخزن بیشتر از سقف مجاز است', { status: 413 });
    return { files: stripTopFolder(await readZip(bytes)), origin: 'مخزن گیت‌هاب' };
  }

  throw new CfError('نوع منبع پشتیبانی نمی‌شود');
}

async function inspect(source, hints = {}) {
  const resolved = await resolveSource(source);
  const detection = detectProject(resolved.files, hints);
  return { resolved, detection };
}

// فایل schema.sql اگر کنار پروژه باشد برای ساخت جداول D1 استفاده می‌شود
function findSchema(files) {
  const candidates = ['schema.sql', 'db/schema.sql', 'sql/schema.sql', 'migrations/schema.sql'];
  for (const path of candidates) {
    const file = files.find(f => f.path === path);
    if (file) return new TextDecoder().decode(file.data);
  }
  return '';
}

// ── استقرار ────────────────────────────────────────────────────────────────
async function deployWorkerWithRetry({ token, accountId, name, files, mainFile, classic, bindings, compatibilityDate, log, sleep }) {
  const existing = await scriptExists(token, accountId, name);
  log('step', existing ? 'آماده‌سازی نسخهٔ «' + name + '»…' : 'استقرار نسخهٔ جدید «' + name + '»…');
  if (existing) await deleteScript(token, accountId, name);

  const uploaded = await uploadWorkerScript({
    token, accountId, name, files, mainFile, bindings, compatibilityDate, classic
  });
  log('ok', 'آپلود نسخه انجام شد (' + uploaded.moduleCount + ' ماژول' + (uploaded.mainModule ? ', ورودی: ' + uploaded.mainModule : '') + ')');

  await enableWorkersDev(token, accountId, name);
  log('ok', 'آدرس workers.dev فعال شد');

  let subdomain = '';
  try { subdomain = await getSubdomain(token, accountId); } catch (_e) { subdomain = ''; }
  const url = 'https://' + name + (subdomain ? '.' + subdomain : '') + '.workers.dev';
  log('step', 'انتظار برای انتشار و تست سلامت…');
  let health = await healthCheck(url, { retries: 4, delayMs: 5000, sleep });

  if (!health.ok && health.reason === '1101') {
    log('warn', 'پاسخ ۱۱۰۱ دیده شد؛ یک تلاش دوبارهٔ خودکار انجام می‌شود');
    await deleteScript(token, accountId, name);
    await uploadWorkerScript({ token, accountId, name, files, mainFile, bindings, compatibilityDate, classic });
    await enableWorkersDev(token, accountId, name);
    log('step', 'تلاش دوم؛ تست سلامت دوباره…');
    health = await healthCheck(url, { retries: 4, delayMs: 5000, sleep });
  }

  if (health.ok) log('ok', 'سلامت تأیید شد (HTTP ' + health.status + ')');
  else if (health.status === 404) log('warn', 'آدرس در حال انتشار است؛ چند ثانیه دیگر آماده می‌شود');
  else log('err', health.reason === '1101' ? 'همچنان ۱۱۰۱ برمی‌گردد؛ تنظیمات binding و فایل ورودی را بررسی کن' : 'آدرس هنوز پاسخ سالم نداد');

  // ۴۰۴ یعنی انتشار هنوز تمام نشده؛ نتیجه را «در حال انتشار» گزارش می‌کنیم
  const pending = !health.ok && health.status === 404;
  return { url, health, pending };
}

async function deployPagesWithRetry({ token, accountId, name, files, log, sleep }) {
  const { created } = await ensurePagesProject(token, accountId, name);
  log('ok', created ? 'پروژهٔ Pages ساخته شد' : 'پروژهٔ Pages از قبل وجود داشت');
  const result = await deployPagesProject({ token, accountId, name, files });
  log('ok', 'آپلود استقرار انجام شد (' + result.uploads + ' فایل)');
  const url = result.url || ('https://' + name + '.pages.dev');
  log('step', 'انتظار برای انتشار و تست سلامت…');
  const health = await healthCheck(url, { retries: 3, delayMs: 5000, sleep });
  if (health.ok) log('ok', 'سلامت تأیید شد (HTTP ' + health.status + ')');
  else log('warn', 'آدرس Pages ممکن است چند دقیقه بعد آماده شود');
  return { url, health, pending: !health.ok && health.status === 404 };
}

async function handleDeploy(request, body) {
  const token = readToken(request);
  const options = body.options || {};
  const steps = [];
  const log = (level, text) => steps.push({ level, text, at: Date.now() });

  try {
    log('step', 'خواندن منبع پروژه…');
    const { resolved, detection } = await inspect(body.source, { name: options.name });
    log('ok', 'منبع خوانده شد: ' + resolved.origin + ' (' + detection.fileCount + ' فایل، ' +
      Math.round(detection.sizeBytes / 1024) + ' KB)');
    log('ok', 'تشخیص: ' + detection.kind + ' — ورودی: ' + (detection.mainFile || 'استاتیک'));

    if (!token) throw new CfError('توکن API کلادفلر را وارد کن', { status: 401 });
    const accountId = readAccount(options.accountId || request.headers.get('x-cf-account'));
    if (!accountId) throw new CfError('حساب کلادفلر انتخاب نشده است');

    const name = String(options.name || detection.name).toLowerCase().replace(/[^a-z0-9-]+/g, '-').slice(0, 54).replace(/-+$/, '') || 'my-panel';
    if (!SLUG_RE.test(name)) throw new CfError('نام استقرار باید با حرف یا رقم شروع شود و فقط a-z، 0-9 و - داشته باشد');
    let mode = options.mode === 'pages' ? 'pages' : 'worker';
    if (detection.mode === 'pages' && options.mode === undefined) mode = 'pages';
    const classic = detection.kind === 'worker-classic';
    const compatibilityDate = String(options.compatibilityDate || detection.compatibilityDate || '2024-11-06');
    if (!DATE_RE.test(compatibilityDate)) throw new CfError('compatibility_date باید به شکل YYYY-MM-DD باشد');
    const bindings = normalizeBindings(Array.isArray(options.bindings) ? options.bindings : detection.bindings);

    // ساخت خودکار D1 در صورت درخواست
    const schemaSql = findSchema(resolved.files);
    if (mode === 'worker' && options.createD1) {
      const dbName = String(options.d1Name || (name + '-db')).replace(/[^a-z0-9-]+/g, '-');
      log('step', 'ساخت دیتابیس D1 با نام «' + dbName + '»…');
      const db = await createD1(token, accountId, dbName);
      const dbId = db?.uuid || db?.id;
      if (!dbId) throw new CfError('ساخت دیتابیس D1 ناموفق بود');
      log('ok', 'دیتابیس ساخته شد: ' + dbId);
      const target = bindings.find(b => b.type === 'd1');
      if (target) target.id = dbId;
      else bindings.push({ type: 'd1', name: 'DB', id: dbId });
      if (schemaSql) {
        const count = await runD1Schema(token, accountId, dbId, schemaSql);
        log('ok', 'schema.sql اجرا شد (' + count + ' دستور)');
      }
    } else if (mode === 'worker') {
      const brokenD1 = bindings.find(b => b.type === 'd1' && !b.id);
      if (brokenD1) log('warn', 'binding «' + brokenD1.name + '» شناسهٔ D1 ندارد؛ ممکن است خطای ۱۱۰۱ بگیری');
    }

    // ساخت خودکار فضای KV و وصل کردنش به اسکریپت (پشتیبانی کامل KV)
    if (mode === 'worker' && options.createKV) {
      const kvName = String(options.kvName || (name + '-kv')).replace(/[^a-z0-9-_]+/g, '-');
      const existingId = String(options.kvNamespaceId || '').trim();
      log('step', existingId ? 'استفاده از فضای KV موجود…' : 'ساخت فضای KV با نام «' + kvName + '»…');
      const ns = existingId
        ? { id: existingId }
        : await createKvNamespace(token, accountId, kvName);
      const nsId = ns?.id;
      if (!nsId) throw new CfError('ساخت فضای KV ناموفق بود');
      log('ok', 'فضای KV آماده است: ' + nsId);
      const kvBinding = bindings.find(b => b.type === 'kv_namespace');
      if (kvBinding) kvBinding.namespace_id = nsId;
      else bindings.push({ type: 'kv_namespace', name: 'KV', namespace_id: nsId });
    } else if (mode === 'worker') {
      const brokenKv = bindings.find(b => b.type === 'kv_namespace' && !b.namespace_id);
      if (brokenKv) log('warn', 'binding «' + brokenKv.name + '» شناسهٔ KV ندارد؛ ممکن است خطای ۱۱۰۱ بگیری');
    }

    // مبهم‌سازی منحصربه‌فرد همین استقرار (بذر تصادفی + کد مرده + اثر انگشت)
    let deployFiles = resolved.files;
    let buildId = '';
    if (options.obfuscate !== false) {
      const seed = randomSeed();
      deployFiles = obfuscateFiles(resolved.files, seed, name);
      buildId = (await fingerprint(deployFiles)).slice(0, 20);
      log('ok', 'مبهم‌سازی منحصربه‌فرد اعمال شد · اثر انگشت ' + buildId);
    } else {
      buildId = (await fingerprint(resolved.files)).slice(0, 20);
    }

    log('step', 'شروع استقرار روی ' + (mode === 'pages' ? 'Pages' : 'Workers') + ' با نام «' + name + '»…');
    const result = mode === 'pages'
      ? await deployPagesWithRetry({ token, accountId, name, files: deployFiles, log, sleep: options._sleep || defaultSleep })
      : await deployWorkerWithRetry({
          token, accountId, name, files: deployFiles, mainFile: detection.mainFile, classic,
          bindings, compatibilityDate, log, sleep: options._sleep || defaultSleep
        });

    const healthy = Boolean(result.health?.ok);
    const ok = healthy || Boolean(result.pending);
    return json({
      success: ok,
      pending: Boolean(result.pending),
      message: healthy
        ? 'استقرار با موفقیت انجام شد و پنل پاسخ می‌دهد'
        : result.pending
          ? 'استقرار انجام شد؛ آدرس در حال انتشار است و تا چند ثانیه باز می‌شود'
          : 'استقرار انجام شد ولی آدرس هنوز پاسخ سالم نداد',
      url: result.url,
      health: result.health,
      mode,
      name,
      fingerprint: buildId,
      detection: {
        kind: detection.kind,
        mainFile: detection.mainFile,
        warnings: detection.warnings,
        fileCount: detection.fileCount,
        sizeBytes: detection.sizeBytes
      },
      steps
    });
  } catch (err) {
    const message = err instanceof CfError ? err.message : String(err?.message || err);
    log('err', message);
    return json({ success: false, message, steps }, err instanceof CfError && err.status ? err.status : 400);
  }
}

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, '') || '/';

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

    if (request.method === 'GET' && (path === '/' || path === '/index.html')) {
      return new Response(renderAppHtml({ origin: url.origin }), {
        headers: { 'Content-Type': 'text/html; charset=utf-8', ...SECURITY_HEADERS }
      });
    }

    // درخواست‌های تغییردهنده فقط هم‌مبدأ (ضد CSRF) و با محدودیت نرخ
    if (request.method === 'POST') {
      const origin = request.headers.get('origin');
      if (origin && origin !== url.origin) return fail('منبع درخواست مجاز نیست', 403);
      const ip = request.headers.get('cf-connecting-ip') || 'unknown';
      if (!allowRequest(ip)) return fail('تعداد درخواست‌ها زیاد است؛ چند دقیقه بعد تلاش کن', 429);
    }

    if (request.method === 'GET' && path === '/health') {
      return json({ success: true, ok: true, name: 'cf-deployer', time: new Date().toISOString() });
    }

    if (request.method === 'GET' && path === '/api/accounts') {
      try {
        const token = readToken(request);
        if (!token) return fail('توکن API کلادفلر را وارد کن', 401);
        const accounts = await listAccounts(token);
        return json({ success: true, accounts });
      } catch (err) {
        return fail(err?.message || 'دریافت حساب‌ها ناموفق بود', err?.status || 400);
      }
    }

    if (request.method === 'POST' && (path === '/api/inspect' || path === '/api/deploy')) {
      const length = Number(request.headers.get('content-length') || 0);
      if (length > MAX_BODY) return fail('حجم درخواست بیشتر از ۱۲ مگابایت است', 413);
      let body;
      try {
        body = await request.json();
      } catch (_e) {
        return fail('بدنهٔ درخواست JSON معتبر نیست', 400);
      }
      if (!body || !body.source) return fail('منبع پروژه (source) ارسال نشده است', 400);

      if (path === '/api/inspect') {
        try {
          const { resolved, detection } = await inspect(body.source, { name: body.options?.name });
          return json({
            success: true,
            origin: resolved.origin,
            detection: {
              mode: detection.mode,
              kind: detection.kind,
              name: detection.name,
              mainFile: detection.mainFile,
              compatibilityDate: detection.compatibilityDate,
              bindings: detection.bindings,
              warnings: detection.warnings,
              fileCount: detection.fileCount,
              sizeBytes: detection.sizeBytes,
              hasSchema: Boolean(findSchema(resolved.files))
            }
          });
        } catch (err) {
          return fail(err?.message || 'تحلیل پروژه ناموفق بود', err?.status || 400);
        }
      }

      return handleDeploy(request, body);
    }

    // لیست فضای نام‌های KV برای انتخاب در رابط کاربری
    if (request.method === 'GET' && path === '/api/kv-namespaces') {
      try {
        const token = readToken(request);
        if (!token) return fail('توکن API کلادفلر را وارد کن', 401);
        const accountId = readAccount(url.searchParams.get('account') || request.headers.get('x-cf-account'));
        if (!accountId) return fail('حساب کلادفلر انتخاب نشده است', 400);
        const namespaces = await listKvNamespaces(token, accountId);
        return json({ success: true, namespaces });
      } catch (err) {
        return fail(err?.message || 'دریافت فضای KV ناموفق بود', err?.status || 400);
      }
    }

    // تست سلامت یک آدرس از سمت سرور (برای انتشار تدریجی و رفع محدودیت CORS)
    if (request.method === 'POST' && path === '/api/health') {
      let body;
      try { body = await request.json(); } catch (_e) { return fail('بدنهٔ JSON معتبر نیست', 400); }
      const target = String(body?.url || '').trim();
      let host = '';
      try { host = new URL(target).hostname.toLowerCase(); } catch (_e) { return fail('آدرس معتبر نیست', 400); }
      // فقط آدرس‌هایی که همین ابزار می‌سازد قابل تست هستند (ضد SSRF)
      if (!/^([a-z0-9-]+\.)+(workers|pages)\.dev$/.test(host)) {
        return fail('فقط آدرس‌های workers.dev و pages.dev مجاز هستند', 400);
      }
      const result = await healthCheck(target, { retries: 2, delayMs: 3000 });
      return json({ success: true, health: result, pending: !result.ok && result.status === 404 });
    }

    if (request.method === 'POST' && path === '/api/delete') {
      try {
        const body = await request.json();
        const token = readToken(request);
        const accountId = readAccount(body.accountId);
        const name = String(body.name || '').trim().toLowerCase();
        if (!token || !accountId || !name) return fail('توکن، حساب و نام لازم است', 400);
        if (!SLUG_RE.test(name)) return fail('نام اسکریپت معتبر نیست', 400);
        if (body.mode === 'pages') {
          await cf(token, `/accounts/${accountId}/pages/projects/${encodeURIComponent(name)}`, { method: 'DELETE' });
        } else {
          await deleteScript(token, accountId, name);
        }
        return json({ success: true, message: 'حذف شد' });
      } catch (err) {
        return fail(err?.message || 'حذف ناموفق بود', err?.status || 400);
      }
    }

    return fail('مسیر پیدا نشد', 404);
  }
};
