// خواندن ZIP بدون هیچ کتابخانه: Central Directory را می‌خوانیم و هر فایل را
// با DecompressionStream('deflate-raw') باز می‌کنیم (روش ۰ = بدون فشرده‌سازی).
// ZIP64 و فایل‌های رمزدار پشتیبانی نمی‌شوند؛ سقف حجم در لایهٔ API چک می‌شود.

const EOCD_SIG = 0x06054b50;
const CENTRAL_SIG = 0x02014b50;

// سقف‌های ضد zip bomb
const MAX_ENTRIES = 1500;
const MAX_ENTRY_BYTES = 8 * 1024 * 1024;
const MAX_TOTAL_BYTES = 40 * 1024 * 1024;
const MAX_NAME_LEN = 240;

export async function readZip(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.length < 22) {
    throw new Error('فایل ZIP خالی یا کوچک‌تر از حد انتظار است');
  }
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

  // امضای پایان فهرست مرکزی معمولاً در ۶۴ کیلوبایت آخر فایل است
  let eocd = -1;
  const min = Math.max(0, bytes.length - 22 - 65535);
  for (let i = bytes.length - 22; i >= min; i--) {
    if (dv.getUint32(i, true) === EOCD_SIG) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('فایل ZIP معتبر نیست (امضای پایان پیدا نشد)');

  const count = dv.getUint16(eocd + 10, true);
  if (count > MAX_ENTRIES) throw new Error('تعداد فایل‌های ZIP بیشتر از سقف مجاز است');
  let offset = dv.getUint32(eocd + 16, true);
  const out = [];
  let total = 0;
  const decoder = new TextDecoder();

  for (let i = 0; i < count; i++) {
    if (offset + 46 > bytes.length || dv.getUint32(offset, true) !== CENTRAL_SIG) break;
    const method = dv.getUint16(offset + 10, true);
    const compSize = dv.getUint32(offset + 20, true);
    const nameLen = dv.getUint16(offset + 28, true);
    const extraLen = dv.getUint16(offset + 30, true);
    const commentLen = dv.getUint16(offset + 32, true);
    const localOffset = dv.getUint32(offset + 42, true);
    const path = decoder.decode(bytes.subarray(offset + 46, offset + 46 + nameLen));
    offset += 46 + nameLen + extraLen + commentLen;

    if (!path || path.endsWith('/')) continue;              // پوشه
    if (path.includes('..') || path.startsWith('/') || path.includes('\\')) continue; // محافظ مسیر
    if (path.length > MAX_NAME_LEN) continue;
    if (localOffset + 30 > bytes.length) continue;

    const localNameLen = dv.getUint16(localOffset + 26, true);
    const localExtraLen = dv.getUint16(localOffset + 28, true);
    const start = localOffset + 30 + localNameLen + localExtraLen;
    if (start + compSize > bytes.length) continue;
    const raw = bytes.subarray(start, start + compSize);

    let data;
    if (method === 0) {
      data = raw;
    } else if (method === 8) {
      data = await inflateRaw(raw);
    } else {
      throw new Error('روش فشرده‌سازی ZIP پشتیبانی نمی‌شود: ' + method);
    }
    if (data.length > MAX_ENTRY_BYTES) throw new Error('یکی از فایل‌های ZIP بیش از ۸ مگابایت است');
    total += data.length;
    if (total > MAX_TOTAL_BYTES) throw new Error('حجم بازشدهٔ ZIP بیشتر از ۴۰ مگابایت است');

    out.push({ path, data });
  }

  if (!out.length) throw new Error('هیچ فایلی داخل ZIP پیدا نشد');
  return out;
}

async function inflateRaw(bytes) {
  if (typeof DecompressionStream !== 'function') {
    throw new Error('محیط اجرا از DecompressionStream پشتیبانی نمی‌کند');
  }
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

// حذف پوشهٔ ریشهٔ زیپ گیت‌هاب (مثل owner-repo-sha/files/...)
export function stripTopFolder(files) {
  if (!files.length) return files;
  const withSlash = files.filter(f => f.path.includes('/'));
  if (withSlash.length < files.length * 0.8) return files;
  const first = files[0].path.split('/')[0];
  if (!files.every(f => f.path.startsWith(first + '/'))) return files;
  return files.map(f => ({ ...f, path: f.path.slice(first.length + 1) }));
}
