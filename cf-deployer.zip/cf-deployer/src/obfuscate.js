// مبهم‌سازی منحصربه‌فرد هر استقرار: هر نسخه با یک «بذر» تصادفی مهر می‌خورد،
// به هر ماژول JS کد مردهٔ تصادفی (decoy) تزریق می‌شود و اثر انگشت SHA-256
// نسخهٔ نهایی ساخته می‌شود. هیچ تغییر معنایی در منطق پروژه ایجاد نمی‌شود.

const JS_RE = /\.(m?js)$/i;
const decoder = new TextDecoder();
const encoder = new TextEncoder();

const hex = bytes => Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');

export function randomSeed() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return hex(bytes);
}

// هش پایدار روی مسیر و محتوای فایل‌ها
export async function fingerprint(files) {
  const sorted = [...files].sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  const parts = [];
  for (const file of sorted) {
    parts.push(encoder.encode(file.path.length + ':' + file.path + ':'));
    parts.push(file.data);
  }
  const size = parts.reduce((n, p) => n + p.length, 0);
  const all = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) { all.set(part, offset); offset += part.length; }
  const digest = await crypto.subtle.digest('SHA-256', all);
  return hex(new Uint8Array(digest));
}

// چند خط کد مردهٔ تصادفی و بی‌اثر؛ نام‌ها با بذر استقرار یکتا می‌شوند
function decoyBlock(seed, index) {
  const num = offset => '0x' + seed.slice(offset, offset + 8);
  const name = '__cfd$' + seed.slice(0, 8) + '$' + index;
  const name2 = '__cfd$' + seed.slice(8, 16) + '$' + index;
  const lines = [
    `;var ${name}=${num(0)};void ${name};`,
    `var ${name2}=[${name}].map(function(v){return v^${num(8)};});void ${name2};`
  ];
  return lines.join('\n');
}

// مهر نسخه + کد مرده روی همهٔ ماژول‌های JS
export function obfuscateFiles(files, seed, label) {
  const tag = seed.slice(0, 10);
  const banner = `/*! build ${tag} · ${label || 'cf-deployer'} · unique-per-deploy */\n`;
  return files.map((file, index) => {
    if (!JS_RE.test(file.path)) return file;
    const source = decoder.decode(file.data);
    const stamped = banner + source + '\n' + decoyBlock(seed, index + 1) + '\n';
    return { ...file, data: encoder.encode(stamped) };
  });
}
